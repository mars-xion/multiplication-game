package data;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ScoreManager implements Serializable {

    public static void saveDataToExcel(List<String[]> data, String filePath) {
        File file = new File(filePath);

        try {
            FileOutputStream fos;
            if (file.exists()) {
                fos = new FileOutputStream(file, true);
            } else {
                fos = new FileOutputStream(file);
                // Write the column headers if the file doesn't exist
                String[] headers = {"Child Username", "Score", "Total Tim", "Number of Questions",
                        "Operand 1", "Operand 2", "T", "Questions Time"};
                writeRowToExcel(fos, headers);
            }

            for (String[] rowData : data) {
                writeRowToExcel(fos, rowData);
            }

            fos.close();

            System.out.println("Score saved to Excel file: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeRowToExcel(FileOutputStream fos, String[] rowData) throws IOException {
        StringBuilder rowBuilder = new StringBuilder();
        for (String cellData : rowData) {
            rowBuilder.append(cellData).append("\t");
        }
        rowBuilder.append("\n");

        fos.write(rowBuilder.toString().getBytes());
    }

    public static List<String[]> readDataFromExcel(String filePath) {
        List<String[]> scoreData = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] rowData = line.split("\t");
                scoreData.add(rowData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return scoreData;
    }
}
