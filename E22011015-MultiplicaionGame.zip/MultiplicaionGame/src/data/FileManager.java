package data;

import model.Exercise;

import java.io.*;

public class FileManager implements Serializable{
    /*
    private static final String FILE_PATH = "data";
    private static int minRange = 0;
    private static int maxRange = 0;
    private static int numQuestions = 0;

    public FileManager(int minRange, int maxRange, int numQuestions) {
        this.minRange = minRange;
        this.maxRange = maxRange;
        this.numQuestions = numQuestions;
    }

    public static void saveData(Object data) {
        try (OutputStream fileOutputStream = new FileOutputStream(FILE_PATH);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
            objectOutputStream.writeObject(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Object loadData() {
        try (InputStream fileInputStream = new FileInputStream(FILE_PATH);
             ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {
            return objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

*/



}

