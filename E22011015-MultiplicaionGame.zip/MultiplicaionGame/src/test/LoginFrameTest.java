package test;

import gui.LoginFrame;
import org.junit.jupiter.api.Test;

import javax.swing.*;
import java.awt.*;

import static org.junit.jupiter.api.Assertions.*;

class LoginFrameTest {

    @Test
    void testAdminAuthentication() {
        // Create an instance of LoginFrame
        LoginFrame loginFrame = new LoginFrame();

        // Simulate entering valid admin credentials
        JTextField usernameTextField = (JTextField) findComponentByName(loginFrame, "usernameTextField");
        JPasswordField passwordField = (JPasswordField) findComponentByName(loginFrame, "passwordField");
        usernameTextField.setText("admin");
        passwordField.setText("admin");

        // Trigger the login button click event
        JButton loginButton = (JButton) findComponentByName(loginFrame, "loginButton");
        loginButton.doClick();

        // Verify that the login is successful by checking if the ParentFrame is displayed
        assertTrue(loginFrame.isVisible());
        assertFalse(loginFrame.isDisplayable());
    }

    @Test
    void testChildAuthentication() {
        // Create an instance of LoginFrame
        LoginFrame loginFrame = new LoginFrame();

        // Simulate entering valid child credentials
        JTextField usernameTextField = (JTextField) findComponentByName(loginFrame, "usernameTextField");
        JPasswordField passwordField = (JPasswordField) findComponentByName(loginFrame, "passwordField");
        usernameTextField.setText("child1");
        passwordField.setText("pass1");

        // Trigger the login button click event
        JButton loginButton = (JButton) findComponentByName(loginFrame, "loginButton");
        loginButton.doClick();

        // Verify that the login is successful by checking if the ChildFrame is displayed
        assertTrue(loginFrame.isVisible());
        assertFalse(loginFrame.isDisplayable());
    }

    @Test
    void testInvalidCredentials() {
        // Create an instance of LoginFrame
        LoginFrame loginFrame = new LoginFrame();

        // Simulate entering invalid credentials
        JTextField usernameTextField = (JTextField) findComponentByName(loginFrame, "usernameTextField");
        JPasswordField passwordField = (JPasswordField) findComponentByName(loginFrame, "passwordField");
        usernameTextField.setText("admin");
        passwordField.setText("wrongpassword");

        // Trigger the login button click event
        JButton loginButton = (JButton) findComponentByName(loginFrame, "loginButton");
        loginButton.doClick();

        // Verify that the login fails and the error message is displayed
        JOptionPane optionPane = (JOptionPane) SwingUtilities.getRoot(loginFrame.getComponent(0));
        assertNotNull(optionPane);
        assertEquals(JOptionPane.ERROR_MESSAGE, optionPane.getMessageType());
    }

    private Component findComponentByName(Container container, String name) {
        for (Component component : container.getComponents()) {
            if (name.equals(component.getName())) {
                return component;
            } else if (component instanceof Container) {
                Component result = findComponentByName((Container) component, name);
                if (result != null) {
                    return result;
                }
            }
        }
        return null;
    }
}
