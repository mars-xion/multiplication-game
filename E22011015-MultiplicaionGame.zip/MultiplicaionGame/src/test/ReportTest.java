package test;

import model.Exercise;
import model.Report;
import model.User;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class ReportTest {
    @Test
    void getUser() {
        User user = new User("child1", "pass1", false);
        Exercise exercise = new Exercise(1, 10, 5);
        Date startTime = new Date();
        Date endTime = new Date();
        int totalTime = 60;
        int totalCorrect = 3;
        int totalIncorrect = 2;

        Report report = new Report(user, exercise, startTime, endTime, totalTime, totalCorrect, totalIncorrect);

        assertEquals(user, report.getUser());
    }

    @Test
    void getExercise() {
        User user = new User("child1", "pass1", false);
        Exercise exercise = new Exercise(1, 10, 5);
        Date startTime = new Date();
        Date endTime = new Date();
        int totalTime = 60;
        int totalCorrect = 3;
        int totalIncorrect = 2;

        Report report = new Report(user, exercise, startTime, endTime, totalTime, totalCorrect, totalIncorrect);

        assertEquals(exercise, report.getExercise());
    }

    @Test
    void getStartTime() {
        User user = new User("child1", "pass1", false);
        Exercise exercise = new Exercise(1, 10, 5);
        Date startTime = new Date();
        Date endTime = new Date();
        int totalTime = 60;
        int totalCorrect = 3;
        int totalIncorrect = 2;

        Report report = new Report(user, exercise, startTime, endTime, totalTime, totalCorrect, totalIncorrect);

        assertEquals(startTime, report.getStartTime());
    }

    @Test
    void getEndTime() {
        User user = new User("child1", "pass1", false);
        Exercise exercise = new Exercise(1, 10, 5);
        Date startTime = new Date();
        Date endTime = new Date();
        int totalTime = 60;
        int totalCorrect = 3;
        int totalIncorrect = 2;

        Report report = new Report(user, exercise, startTime, endTime, totalTime, totalCorrect, totalIncorrect);

        assertEquals(endTime, report.getEndTime());
    }

    @Test
    void getTotalTime() {
        User user = new User("child1", "pass1", false);
        Exercise exercise = new Exercise(1, 10, 5);
        Date startTime = new Date();
        Date endTime = new Date();
        int totalTime = 60;
        int totalCorrect = 3;
        int totalIncorrect = 2;

        Report report = new Report(user, exercise, startTime, endTime, totalTime, totalCorrect, totalIncorrect);

        assertEquals(totalTime, report.getTotalTime());
    }

    @Test
    void getTotalCorrect() {
        User user = new User("child1", "pass1", false);
        Exercise exercise = new Exercise(1, 10, 5);
        Date startTime = new Date();
        Date endTime = new Date();
        int totalTime = 60;
        int totalCorrect = 3;
        int totalIncorrect = 2;

        Report report = new Report(user, exercise, startTime, endTime, totalTime, totalCorrect, totalIncorrect);

        assertEquals(totalCorrect, report.getTotalCorrect());
    }

    @Test
    void getTotalIncorrect() {
        User user = new User("child1", "pass1", false);
        Exercise exercise = new Exercise(1, 10, 5);
        Date startTime = new Date();
        Date endTime = new Date();
        int totalTime = 60;
        int totalCorrect = 3;
        int totalIncorrect = 2;

        Report report = new Report(user, exercise, startTime, endTime, totalTime, totalCorrect, totalIncorrect);

        assertEquals(totalIncorrect, report.getTotalIncorrect());
    }
}
