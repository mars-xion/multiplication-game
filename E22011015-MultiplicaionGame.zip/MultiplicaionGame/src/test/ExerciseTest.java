package test;

import model.Exercise;
import gui.ExerciseSettings;
import model.Question;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExerciseTest {
    private Exercise exercise;
    private ExerciseSettings exerciseSettings;

    @BeforeEach
    void setUp() {
        exerciseSettings = new ExerciseSettings();
        exerciseSettings.setMinRange(1);
        exerciseSettings.setMaxRange(10);
        exerciseSettings.setNumQuestions(5);

        exercise = new Exercise(1, 10,
                5);
    }

    @Test
    void generateExercise() {
        List<Question> questions = exercise.generateExercise();

        assertNotNull(questions);
        assertEquals(exerciseSettings.getNumQuestions(), questions.size());

        for (Question question : questions) {
            int operand1 = question.getOperand1();
            int operand2 = question.getOperand2();

            //assertTrue(5, 3, 15);
            //assertTrue(operand2 >= exerciseSettings.getMinRange() && operand2 <= exerciseSettings.getMaxRange());
        }
    }
}
