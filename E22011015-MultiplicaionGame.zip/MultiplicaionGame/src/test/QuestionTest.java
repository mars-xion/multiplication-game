package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class QuestionTest {

    @Test
    void getOperand1() {
        int operand1 = 5;
        int operand2 = 10;
        Question question = new Question(operand1, operand2);

        assertEquals(operand1, question.getOperand1());
    }

    @Test
    void getOperand2() {
        int operand1 = 5;
        int operand2 = 10;
        Question question = new Question(operand1, operand2);

        assertEquals(operand2, question.getOperand2());
    }

    @Test
    void getAnswer() {
        int operand1 = 5;
        int operand2 = 10;
        Question question = new Question(operand1, operand2);
        int expectedAnswer = operand1 + operand2;

        assertEquals(expectedAnswer, question.getAnswer());
    }

    @Test
    void getGeneratedQuestion() {
        int operand1 = 5;
        int operand2 = 10;
        Question question = new Question(operand1, operand2);
        String expectedGeneratedQuestion = "What is the sum of 5 and 10?";

        assertEquals(expectedGeneratedQuestion, question.getGeneratedQuestion());
    }
}
