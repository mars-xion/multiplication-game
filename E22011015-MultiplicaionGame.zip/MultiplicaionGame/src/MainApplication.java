import javafx.application.Application;
import javafx.stage.Stage;

import gui.LoginFrame;

public class MainApplication extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create and display the login window
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
