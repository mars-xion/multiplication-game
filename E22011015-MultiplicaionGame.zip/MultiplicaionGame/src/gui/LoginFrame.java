package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private static final String TITLE = "Login Screen";

    public LoginFrame() {
        super(TITLE);
        init();
    }

    private void init() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(10, 10, 10, 10);

        // Create labels, text fields, and a button for the login form
        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameTextField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");

        // Add the components to the panel
        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(usernameLabel, constraints);

        constraints.gridx = 1;
        panel.add(usernameTextField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        panel.add(passwordLabel, constraints);

        constraints.gridx = 1;
        panel.add(passwordField, constraints);

        constraints.gridx = 1;
        constraints.gridy = 2;
        panel.add(loginButton, constraints);

        // Handle the login button click event
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameTextField.getText();
                String password = new String(passwordField.getPassword());

                try {
                    authenticate(username, password);

                    // Display a success message
                    JOptionPane.showMessageDialog(null, "Login successful!", "Login Successful", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    // Display an error message for invalid credentials
                    JOptionPane.showMessageDialog(null, ex.getMessage(), "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(panel, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }

    private void authenticate(String username, String password) throws Exception {
        if (username.equals("admin") && password.equals("admin")) {
            // Show admin main window
            ParentFrame parentFrame = new ParentFrame();
            parentFrame.setVisible(true);
            dispose();
            return;
        }

        if (username.startsWith("child")) {
            // Extract the child number from the role
            int childNumber;
            try {
            childNumber = Integer.parseInt(username.substring(5));
            } catch (Exception e){
                throw new Exception("Invalid username or password!");
            }
            if (password.equals("pass" + childNumber)) {
                // Show child main window
                ChildFrame childFrame = new ChildFrame(childNumber);
                childFrame.setVisible(true);
                dispose();
                return;
            }

        }

        throw new Exception("Invalid username or password!");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame().setVisible(true);
            }
        });
    }
}
