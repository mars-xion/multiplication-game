package gui;

import model.Question;
import model.Exercise;
import data.ScoreManager;
import timeforapp.ExerciseData;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;



public class ExerciseDialog extends JFrame {
    private int score = 0;
    private int currentQuestionIndex = 0;
    public int totalQuestions = 0;
    private List<Question> quiz;

    private JLabel questionLabel;
    private JTextField answerTextField;
    private JButton submitButton;
    private JButton closeButton;
    private JLabel timerLabel;
    private Instant questionStartTime;
    private Instant questionSubmitTime;
    private Timer questionTimer;
    private Instant questionStopTime;
    private Instant currentQuestionStartTime;

    private JLabel resultLabel;
    private JLabel scoreLabel;
    private ChildFrame childFrame;
    private String childName;

    private List<ExerciseData> exerciseDataList;
    //private ExerciseData exerciseData; // Declare exerciseData as a member variable
    private List<String> questionList; // Store the generated questions
    private List<Long> timeTakenList;


    public ExerciseDialog(int minRange, int maxRange, int numQuestions, String childName, int totalQuestions) {
        setTitle("Multiplication App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        this.childName = childName;
        this.totalQuestions = totalQuestions;
        this.exerciseDataList = new ArrayList<>();
        this.currentQuestionIndex = 0; // Start from the first question
        this.questionList = new ArrayList<>(); // Initialize the question list
        this.resultLabel = new JLabel("Total Questions: " + totalQuestions);
        this.timeTakenList = new ArrayList<>();

        Exercise quizGenerator = new Exercise(minRange, maxRange, numQuestions);
        quiz = quizGenerator.generateExercise();
        exerciseDataList = new ArrayList<>();

        JLabel titleLabel = new JLabel("Multiplication Exercise");

        questionLabel = new JLabel();
        answerTextField = new JTextField(10);

        submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processAnswer();
            }
        });

        resultLabel = new JLabel();
        scoreLabel = new JLabel();
        timerLabel = new JLabel();

        add(titleLabel);
        add(questionLabel);
        add(answerTextField);
        add(submitButton);
        add(resultLabel);
        add(scoreLabel);
        add(timerLabel);

        showNextQuestion();
        startQuestionTimer();
        timerLabel.setText("");

        setVisible(true);
    }

    private void showNextQuestion() {
        if (currentQuestionIndex < quiz.size()) {
            Question question = quiz.get(currentQuestionIndex);
            questionLabel.setText(question.getOperand1() + " x " + question.getOperand2() + " =");
            answerTextField.setText("");
            submitButton.setEnabled(true);
            resultLabel.setText("");
            scoreLabel.setText("Score: " + score + "/" + quiz.size());

            // Store the question in the list
            questionList.add(question.getOperand1() + " x " + question.getOperand2() + " = ?");

            // Set the start time for the current question
            currentQuestionStartTime = Instant.now();

        } else {
            showQuizSummary();
            System.out.println("NextQuestion");
        }
    }



    private void processAnswer() {
        if (currentQuestionIndex < quiz.size()) {
            Question question = quiz.get(currentQuestionIndex);
            int userAnswer = Integer.parseInt(answerTextField.getText().trim());
            if (userAnswer == question.getAnswer()) {
                score++;
                resultLabel.setText("Correct!");
            } else {
                resultLabel.setText("Incorrect!");
            }

            // Calculate the time taken for the current question
            Instant currentTime = Instant.now();
            Duration duration = Duration.between(currentQuestionStartTime, currentTime);
            long questionTime = duration.getSeconds();
            timeTakenList.add(questionTime);

            ExerciseData exerciseData = new ExerciseData(
                    question.getOperand1(),
                    question.getOperand2(),
                    question.getAnswer(),
                    userAnswer,
                    questionTime,
                    getGeneratedQuestion(currentQuestionIndex)
            );
            exerciseDataList.add(exerciseData);

            currentQuestionIndex++;
            submitButton.setEnabled(false);
            showNextQuestion();

        }
    }

    private void startQuestionTimer() {
        questionStartTime = Instant.now();
        questionTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Duration duration = Duration.between(questionStartTime, Instant.now());
                long seconds = duration.getSeconds();
                timerLabel.setText("Time: " + seconds + " seconds");
            }
        });
        questionTimer.start();
    }

    private void stopQuestionTimer() {
        if (questionTimer != null && questionTimer.isRunning()) {
            questionTimer.stop();
        }
    }

    private long getQuestionTime() {
        Instant now = Instant.now();
        Duration duration = Duration.between(questionStartTime, now);
        return duration.getSeconds();
    }

    private void showQuizSummary() {
        String name = childName.isEmpty() ? "Child" : childName;
        questionLabel.setText("Quiz Completed!");
        answerTextField.setText("");
        submitButton.setEnabled(false);
        resultLabel.setText("");
        scoreLabel.setText("Final Score for " + name + ": " + score + "/" + quiz.size());

        questionStopTime = Instant.now(); // Initialize the questionStopTime
        questionSubmitTime = Instant.now(); // Store the time when all questions are answered

        timerLabel.setText("Total taken Time: " + getTotalTime() + " seconds");
        stopQuestionTimer();

        closeButton = new JButton("Close");
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBackToChildFrame();
            }
        });

        add(closeButton);
    }

    private String getGeneratedQuestion(int index) {
        if (index >= 0 && index < quiz.size()) {
            Question question = quiz.get(index);
            return question.getGeneratedQuestion();
        }
        return null;
    }

    private List<String> getQuestionListWithAnswers() {
        List<String> questionListWithAnswers = new ArrayList<>();
        for (Question question : quiz) {
            String questionText = question.getOperand1() + " x " + question.getOperand2() + " =";
            String questionWithAnswer = questionText + question.getAnswer();
            questionListWithAnswers.add(questionWithAnswer);
        }
        return questionListWithAnswers;
    }

    private void appendQuestionTimeToStringArray(List<String[]> data) {
        for (int i = 0; i < exerciseDataList.size(); i++) {
            ExerciseData exerciseData = exerciseDataList.get(i);
            String questionTime = Long.toString(exerciseData.getQuestionTime());
            String[] rowData = {
                    "", "", "", "", "", "", "Time taken for Question " + (i + 1), questionTime
            };
        }
    }


    private String getTotalTime() {
        Duration duration = Duration.between(questionStartTime, questionStopTime);
        long seconds = duration.getSeconds();
        return Long.toString(seconds) + " seconds";
    }

    private void goBackToChildFrame() {
        dispose(); // Close the ExerciseDialog

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                childFrame.setVisible(true); // Make the ChildFrame visible
                childFrame.setQuizResult(childName, score, quiz.size()); // Pass the quiz result to ChildFrame

                // Save the score, child name, and time to the Excel file
                String filePath = "scores.xlsx";
                // Create the data list for saving to Excel
                List<String[]> data = new ArrayList<>();

                // Create the rowData array for the last exerciseData
                ExerciseData lastExerciseData = exerciseDataList.get(exerciseDataList.size() - 1);
                String operand1 = Integer.toString(lastExerciseData.getOperand1());
                String operand2 = Integer.toString(lastExerciseData.getOperand2());
                String generatedQuestion = lastExerciseData.getGeneratedQuestion();

                // Get the questions as a single string separated by a delimiter
                String questionsString = String.join(", ", getQuestionListWithAnswers());

                StringBuilder questionTimeBuilder = new StringBuilder();
                for (int i = 0; i < exerciseDataList.size(); i++) {
                    ExerciseData exerciseData = exerciseDataList.get(i);
                    String questionTimeString = "Question " + (i + 1) + ": " + exerciseData.getQuestionTime() + " seconds";
                    questionTimeBuilder.append(questionTimeString);
                    if (i < exerciseDataList.size() - 1) {
                        questionTimeBuilder.append(", ");
                    }
                }
                String questionTime = questionTimeBuilder.toString();

                String[] rowData = {
                        childName,
                        Integer.toString(score),
                        getTotalTime(),
                        Integer.toString(quiz.size()),
                        operand1,
                        operand2,
                        questionsString,
                        questionTime
                };
                data.add(rowData);

                ScoreManager.saveDataToExcel(data, filePath);

            /*
            // reset data to allow the child to run the quiz again
            score = 0;
            currentQuestionIndex = 0;
            totalQuestions = 0;
            questionStartTime = 0;
            */
            }
        });
    }



    public void setChildFrame(ChildFrame childFrame) {
        this.childFrame = childFrame;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                int minRange = 1;
                int maxRange = 10;
                int numQuestions = 5;
                String childName = ""; // Replace with the child's name
                int totalQuestions = 0; // Replace with the total number of questions

                new ExerciseDialog(minRange, maxRange, numQuestions, childName, totalQuestions);
            }
        });
    }
}