package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ParentFrame extends JFrame {
    private static final String TITLE = "Parent Screen";
    private ExerciseSettings exerciseSettings;

    public ParentFrame() {
        super(TITLE);
        exerciseSettings = new ExerciseSettings();
        init();
    }

    private void init() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Added buttons
        JButton settingsButton = new JButton("Exercise Settings");
        JButton reportsButton = new JButton("View Reports");
        JButton logoutButton = new JButton("Logout");

        panel.add(settingsButton);
        panel.add(reportsButton);
        panel.add(logoutButton);

        // Set preferred size for buttons
        Dimension buttonSize = new Dimension(140, 30);
        settingsButton.setPreferredSize(buttonSize);
        reportsButton.setPreferredSize(buttonSize);
        logoutButton.setPreferredSize(new Dimension(295, 30));

        add(panel);
        pack();
        setSize(400, 180);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showExerciseSettingsDialog();
            }
        });

        reportsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showReports();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });
    }

    private void showExerciseSettingsDialog() {
        ExerciseSettings settingsDialog = new ExerciseSettings(this, exerciseSettings);
        settingsDialog.setVisible(true);
    }

    private void showReports() {
        // Create and show the ChildScoresReportDialog
        ChildScoresReportDialog reportDialog = new ChildScoresReportDialog(this);
        reportDialog.setVisible(true);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ParentFrame().setVisible(true);
            }
        });
    }

    private void logout() {
        dispose(); // Close the current window

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                // Replace LoginFrame with the appropriate code to create and display the login frame
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            }
        });
    }
}
