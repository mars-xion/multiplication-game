package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChildFrame extends JFrame {
    private static final String TITLE = "Child Screen";
    private int childNumber;
    private JLabel childLabel;
    private JButton startButton;
    private JButton logoutButton;

    private int minRange;
    private int maxRange;
    private int numQuestions;

    private String childName;
    private int childScore;
    private int totalQuestions;
    private ExerciseDialog exerciseDialog;

    private boolean nameEntered = false; // Flag to track if name has been entered

    public ChildFrame(int childNumber) {
        super(TITLE);
        this.childNumber = childNumber;
        init();
    }

    private void init() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        childLabel = new JLabel("Child " + childNumber);
        startButton = new JButton("Start Exercise");
        logoutButton = new JButton("Logout");

        // Set preferred size for the buttons
        startButton.setPreferredSize(new Dimension(120, 30));
        logoutButton.setPreferredSize(new Dimension(120, 30));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0)); // Add top padding to the button panel
        buttonPanel.add(startButton);
        buttonPanel.add(Box.createHorizontalStrut(10)); // Add horizontal space between the buttons
        buttonPanel.add(logoutButton);

        panel.add(childLabel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);
        pack();
        setSize(400, 170);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!nameEntered) {
                    String name = JOptionPane.showInputDialog(ChildFrame.this, "Enter your name:");
                    if (name != null && !name.isEmpty()) {
                        nameEntered = true;
                        showExerciseDialog(name);
                    } else {
                        JOptionPane.showMessageDialog(ChildFrame.this, "Please enter your name.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    showExerciseDialog("");
                }
            }
        });

        setQuizResult("", 0, 0);

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

    }

    private void showExerciseDialog(String name) {
        String altName = name.isEmpty() ? childName : name; // Use the previous name if the input is empty
        exerciseDialog = new ExerciseDialog(minRange, maxRange, numQuestions, altName, totalQuestions);
        exerciseDialog.setChildFrame(this); // Pass the reference to ChildFrame
        exerciseDialog.setVisible(true); // Show the ExerciseDialog
        setVisible(false); // Hide the ChildFrame
    }


    public void setExerciseSettings(int numQuestions, int minRange, int maxRange) {
        this.numQuestions = numQuestions;
        this.minRange = minRange;
        this.maxRange = maxRange;
    }

    public void setQuizResult(String name, int score, int totalQuestions) {
        this.childName = name;
        this.childScore = score;
        this.totalQuestions = totalQuestions;
        updateChildLabel();
    }

    private void updateChildLabel() {
        childLabel.setText("Child " + childNumber + " - Quiz Result for " + childName + ": " + childScore + "/" + totalQuestions);
    }

    private void logout() {
        dispose(); // Close the current window

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ChildFrame childFrame = new ChildFrame(childNumber);
                childFrame.setExerciseSettings(numQuestions, minRange, maxRange);
                childFrame.setQuizResult(childName, childScore, totalQuestions);

                // Replace LoginFrame with the appropriate code to create and display the login frame
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            }
        });
    }

}
