package gui;

import data.ScoreManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ChildScoresReportDialog extends JDialog {
    private JTable scoreTable;

    public ChildScoresReportDialog(Frame parent) {
        super(parent, "Child Scores Report", true);
        initComponents();
        pack();
        setLocationRelativeTo(parent);
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Child Scores Report");
        panel.add(titleLabel, BorderLayout.NORTH);

        List<String[]> scoreData = ScoreManager.readDataFromExcel("scores.xlsx");
        createScoreTable(scoreData);
        panel.add(new JScrollPane(scoreTable), BorderLayout.CENTER);

        getContentPane().add(panel);

        // Set the preferred size of the dialog
        setPreferredSize(new Dimension(1000, 500));
    }


    private void createScoreTable(List<String[]> scoreData) {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Child Username");
        model.addColumn("Score");
        model.addColumn("Time");
        model.addColumn("Number of Questions");
        model.addColumn("Operand 1");
        model.addColumn("Operand 2");
        model.addColumn("T");
        model.addColumn("Questions Time");

        for (String[] rowData : scoreData) {
            model.addRow(rowData);
        }

        scoreTable = new JTable(model);
    }

}
