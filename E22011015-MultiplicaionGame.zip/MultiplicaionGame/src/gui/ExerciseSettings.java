package gui;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExerciseSettings extends JDialog {
    private ExerciseSettings exerciseSettings;
    private JComboBox<Integer> minRangeComboBox;
    private JComboBox<Integer> maxRangeComboBox;
    private JTextField numQuestionsTextField;
    private JButton saveButton;
    private JButton cancelButton;
    private Object minRange;
    private Object maxRange;
    private int numQuestions;

    public ExerciseSettings() {
        minRange = 10;
        maxRange = 10;
        numQuestions = 5;
    }


    public Object getMinRange() {

        return minRange;
    }

    public void setMinRange(Object minRange) {

        this.minRange = minRange;
    }

    public Object getMaxRange() {

        return maxRange;
    }

    public void setMaxRange(Object maxRange) {

        this.maxRange = maxRange;
    }

    public int getNumQuestions() {
        return numQuestions;
    }

    public void setNumQuestions(int numQuestions) {

        this.numQuestions = numQuestions;
    }

    public ExerciseSettings(JFrame parentFrame, ExerciseSettings exerciseSettings) {
        super(parentFrame, "Exercise Settings", true);
        this.exerciseSettings = exerciseSettings;
        init();
    }

    private void init() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(10, 10, 10, 10);

        JLabel minRangeLabel = new JLabel("Minimum Range:");
        JLabel maxRangeLabel = new JLabel("Maximum Range:");
        JLabel numQuestionsLabel = new JLabel("Number of Questions:");

        minRangeComboBox = new JComboBox<>();
        maxRangeComboBox = new JComboBox<>();
        numQuestionsTextField = new JTextField(10);
        saveButton = new JButton("Save");
        cancelButton = new JButton("Cancel");

        // Populate the drop-down boxes for a and b ranges from 1 to 10
        for (int i = 1; i <= 10; i++) {
            minRangeComboBox.addItem(i);
            maxRangeComboBox.addItem(i);
        }

        // Set the initial selection of a and b ranges from the exercise settings
        minRangeComboBox.setSelectedItem(exerciseSettings.getMinRange());
        maxRangeComboBox.setSelectedItem(exerciseSettings.getMaxRange());

        // Set the initial number of questions from the exercise settings
        numQuestionsTextField.setText(Integer.toString(exerciseSettings.getNumQuestions()));

        constraints.gridx = 0;
        constraints.gridy = 0;
        panel.add(minRangeLabel, constraints);

        constraints.gridx = 1;
        panel.add(minRangeComboBox, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        panel.add(maxRangeLabel, constraints);

        constraints.gridx = 1;
        panel.add(maxRangeComboBox, constraints);

        constraints.gridx = 0;
        constraints.gridy = 2;
        panel.add(numQuestionsLabel, constraints);

        constraints.gridx = 1;
        panel.add(numQuestionsTextField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 3;
        constraints.gridwidth = 2;
        panel.add(saveButton, constraints);

        constraints.gridy = 4;
        panel.add(cancelButton, constraints);

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveSettings();
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }

    private void saveSettings() {
        int minRange = (int) minRangeComboBox.getSelectedItem();
        int maxRange = (int) maxRangeComboBox.getSelectedItem();
        int numQuestions = Integer.parseInt(numQuestionsTextField.getText());

        // Update the exercise settings
        exerciseSettings.setMinRange(minRange);
        exerciseSettings.setMaxRange(maxRange);
        exerciseSettings.setNumQuestions(numQuestions);

        try {
            // Open the text file for writing
            FileWriter writer = new FileWriter("data.txt");

            // Create a list and add the integers
            List<Integer> numbers = new ArrayList<>();
            numbers.add(minRange);
            numbers.add(maxRange);
            numbers.add(numQuestions);

            // Convert the list elements to strings and join them with commas
            String data = String.join(",", numbers.stream().map(Object::toString).toArray(String[]::new));

            // Write the string to the text file
            writer.write(data);

            // Close the text file
            writer.close();

            System.out.println("New settings saved");
        } catch (IOException e) {
            e.printStackTrace();
        }

        dispose();
    }



}
