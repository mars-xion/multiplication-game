package model;

import gui.ExerciseSettings;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Exercise {
    private int minRange;
    private int maxRange;
    private int numQuestions;
    ExerciseSettings exerciseSettings = retrievedata();

    public Exercise(int minRange, int maxRange, int numQuestions) {
        this.minRange = minRange;
        this.maxRange = maxRange;
        this.numQuestions = numQuestions;
        ExerciseSettings exerciseSettings = retrievedata();

        this.minRange = (int)exerciseSettings.getMinRange();
        this.maxRange = (int)exerciseSettings.getMaxRange();;
        this.numQuestions = exerciseSettings.getNumQuestions();


        // Call the retrievedata method to retrieve the saved data
        retrievedata();
    }

    public static ExerciseSettings retrievedata() {
        ExerciseSettings exerciseSettings = new ExerciseSettings();

        try {
            // Open the text file for reading
            FileReader fileReader = new FileReader("data.txt");
            BufferedReader reader = new BufferedReader(fileReader);

            // Read the line containing the saved data
            String data = reader.readLine();

            // Split the data string into individual values
            String[] values = data.split(",");

            // Parse and set the values in the exercise settings
            exerciseSettings.setMinRange(Integer.parseInt(values[0]));
            exerciseSettings.setMaxRange(Integer.parseInt(values[1]));
            exerciseSettings.setNumQuestions(Integer.parseInt(values[2]));

            // Close the reader
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }


        return exerciseSettings;
    }

    public List<Question> generateExercise() {
        List<Question> questions = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < numQuestions; i++) {
            int operand1 = random.nextInt(maxRange - minRange + 1) + minRange;
            int operand2 = random.nextInt(maxRange - minRange + 1) + minRange;
            questions.add(new Question(operand1, operand2));
        }

        return questions;
    }
}

