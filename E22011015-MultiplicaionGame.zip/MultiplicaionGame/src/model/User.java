package model;

import java.io.Serializable;

public class User implements Serializable {
    private String username;
    private String password;
    private boolean isParent;

    public User(String username, String password, boolean isParent) {
        this.username = username;
        this.password = password;
        this.isParent = isParent;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public boolean isParent() {
        return isParent;
    }
}
