package model;

public class Question {
    private int operand1;
    private int operand2;
    private int answer;
    private String generatedQuestion;

    public Question(int operand1, int operand2) {
        this.operand1 = operand1;
        this.operand2 = operand2;
        this.answer = operand1 * operand2;
        this.generatedQuestion = generatedQuestion;
    }

    public int getOperand1() {
        return operand1;
    }

    public int getOperand2() {
        return operand2;
    }

    public int getAnswer() {
        return answer;
    }

    public String getGeneratedQuestion() {
        return generatedQuestion;
    }

}
