package model;

import java.io.Serializable;
import java.util.Date;

public class Report implements Serializable {
    private User user;
    private Exercise exercise;
    private Date startTime;
    private Date endTime;
    private int totalTime;
    private int totalCorrect;
    private int totalIncorrect;

    public Report(User user, Exercise exercise, Date startTime, Date endTime, int totalTime, int totalCorrect, int totalIncorrect) {
        this.user = user;
        this.exercise = exercise;
        this.startTime = startTime;
        this.endTime = endTime;
        this.totalTime = totalTime;
        this.totalCorrect = totalCorrect;
        this.totalIncorrect = totalIncorrect;
    }

    public User getUser() {
        return user;
    }

    public Exercise getExercise() {
        return exercise;
    }

    public Date getStartTime() {
        return startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public int getTotalTime() {
        return totalTime;
    }

    public int getTotalCorrect() {
        return totalCorrect;
    }

    public int getTotalIncorrect() {
        return totalIncorrect;
    }
}
