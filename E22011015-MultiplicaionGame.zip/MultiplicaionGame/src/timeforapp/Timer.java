package timeforapp;


import java.util.TimerTask;

public class Timer {
    private java.util.Timer timer;
    private int elapsedSeconds;
    private TimerCallback callback;

    public Timer(TimerCallback callback) {
        this.timer = new java.util.Timer();
        this.elapsedSeconds = 0;
        this.callback = callback;
    }

    public void startTimer() {
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                elapsedSeconds++;
                callback.onTimerTick(elapsedSeconds);
            }
        }, 1000, 1000);
    }

    public void stopTimer() {
        timer.cancel();
    }

    public interface TimerCallback {
        void onTimerTick(int elapsedSeconds);
    }
}

