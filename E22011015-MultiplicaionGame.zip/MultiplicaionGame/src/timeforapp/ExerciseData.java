package timeforapp;

public class ExerciseData {
    private int operand1;
    private int operand2;
    private long questionTime;
    private String generatedQuestion;

    public ExerciseData(int operand1, int operand2, int correctAnswer, int userAnswer, long questionTime, String generatedQuestion) {
        this.operand1 = operand1;
        this.operand2 = operand2;
        this.questionTime = questionTime;
        this.generatedQuestion = generatedQuestion;
    }

    public int getOperand1() {
        return operand1;
    }

    public int getOperand2() {
        return operand2;
    }

    public long getQuestionTime() {
        return questionTime;
    }

    public String getGeneratedQuestion() {
        return generatedQuestion;
    }
}
